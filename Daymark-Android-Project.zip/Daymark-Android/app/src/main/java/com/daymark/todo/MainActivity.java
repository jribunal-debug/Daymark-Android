package com.daymark.todo;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
 private WebView webView;
 private ValueCallback<Uri[]> fileCallback;
 private static final int PICK_FILE = 1001;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  webView = new WebView(this);
  webView.getSettings().setJavaScriptEnabled(true);
  webView.getSettings().setDomStorageEnabled(true);
  webView.getSettings().setAllowFileAccess(true);
  webView.getSettings().setAllowContentAccess(true);
  webView.setWebViewClient(new WebViewClient());
  webView.setWebChromeClient(new WebChromeClient() {
   @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
    if (fileCallback != null) fileCallback.onReceiveValue(null);
    fileCallback = cb;
    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("application/json");
    try { startActivityForResult(Intent.createChooser(i, "Select Daymark backup"), PICK_FILE); }
    catch (Exception e) { fileCallback = null; return false; }
    return true;
   }
  });
  setContentView(webView);
  webView.loadUrl("file:///android_asset/index.html");
 }
 @Override protected void onActivityResult(int r, int c, Intent d) {
  super.onActivityResult(r,c,d);
  if (r == PICK_FILE && fileCallback != null) {
   Uri[] result = c == RESULT_OK && d != null && d.getData() != null ? new Uri[]{d.getData()} : null;
   fileCallback.onReceiveValue(result); fileCallback = null;
  }
 }
 @Override public void onBackPressed() {
  if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
 }
 @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}

# Daymark Android project
The included GitHub Actions workflow builds a debug APK on every push to `main`, or manually from the Actions tab.
Download the `Daymark-APK` artifact and extract `app-debug.apk`.
The app loads `app/src/main/assets/index.html`; JavaScript and DOM storage are enabled for Daymark local task storage.
\n## Task notifications\nOpen a detailed task and choose a reminder date and time. Allow Daymark notifications when Android asks. Reminders are scheduled by Android and can appear while the app is closed. Completed or deleted tasks cancel their reminders.\n
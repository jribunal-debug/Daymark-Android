package com.daymark.todo;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
 static final String CHANNEL="daymark_reminders";
 static void createChannel(Context c) {
  if (Build.VERSION.SDK_INT >= 26) {
   NotificationChannel ch=new NotificationChannel(CHANNEL,"Task reminders",NotificationManager.IMPORTANCE_DEFAULT);
   ch.setDescription("Notifications for your Personal and Work tasks");
   ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
  }
 }
 static int notificationId(String id) { return id.hashCode() & 0x7fffffff; }
 static PendingIntent pending(Context c,String id,String title,String area,long time,int flags) {
  Intent i=new Intent(c,ReminderReceiver.class);
  i.setAction("com.daymark.todo.REMIND."+id);
  i.putExtra("id",id); i.putExtra("title",title); i.putExtra("area",area);
  return PendingIntent.getBroadcast(c,notificationId(id),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE|flags);
 }
 static void schedule(Context c,String id,String title,String area,long time) {
  if (time <= System.currentTimeMillis()) { cancel(c,id); return; }
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  PendingIntent pi=pending(c,id,title,area,time,0);
  am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pi);
  try {
   SharedPreferences sp=c.getSharedPreferences("daymark_reminders",Context.MODE_PRIVATE);
   JSONObject item=new JSONObject(); item.put("id",id);item.put("title",title);item.put("area",area);item.put("time",time);
   JSONArray arr=new JSONArray(sp.getString("items","[]")); JSONArray next=new JSONArray();
   for(int n=0;n<arr.length();n++){JSONObject old=arr.getJSONObject(n);if(!id.equals(old.optString("id")))next.put(old);}
   next.put(item);sp.edit().putString("items",next.toString()).apply();
  } catch(Exception ignored) {}
 }
 static void cancel(Context c,String id) {
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  PendingIntent pi=pending(c,id,"","",0,0); am.cancel(pi); pi.cancel();
  try {
   SharedPreferences sp=c.getSharedPreferences("daymark_reminders",Context.MODE_PRIVATE);
   JSONArray arr=new JSONArray(sp.getString("items","[]"));JSONArray next=new JSONArray();
   for(int n=0;n<arr.length();n++){JSONObject old=arr.getJSONObject(n);if(!id.equals(old.optString("id")))next.put(old);}
   sp.edit().putString("items",next.toString()).apply();
  } catch(Exception ignored) {}
 }
 @Override public void onReceive(Context c,Intent intent) {
  String id=intent.getStringExtra("id");
  if("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) return;
  if(id==null)return;
  createChannel(c);
  String title=intent.getStringExtra("title"),area=intent.getStringExtra("area");
  Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
  PendingIntent content=PendingIntent.getActivity(c,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new NotificationCompat.Builder(c,CHANNEL)
   .setSmallIcon(android.R.drawable.ic_dialog_info)
   .setContentTitle("Daymark · "+("work".equals(area)?"Work":"Personal"))
   .setContentText(title==null?"Task reminder":title)
   .setStyle(new NotificationCompat.BigTextStyle().bigText(title==null?"Task reminder":title))
   .setAutoCancel(true).setContentIntent(content).build();
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(notificationId(id),n);
  cancel(c,id);
 }
}

package com.daymark.todo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;

public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i) {
  if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()))return;
  try {
   JSONArray arr=new JSONArray(c.getSharedPreferences("daymark_reminders",Context.MODE_PRIVATE).getString("items","[]"));
   for(int n=0;n<arr.length();n++){
    JSONObject o=arr.getJSONObject(n);
    ReminderReceiver.schedule(c,o.getString("id"),o.getString("title"),o.getString("area"),o.getLong("time"));
   }
  } catch(Exception ignored) {}
 }
}
